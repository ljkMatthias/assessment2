const fetch = require("node-fetch");

exports.getData = async (event) => {
  const url = "https://jsonplaceholder.typicode.com/users";

  fetch(url)
    .then((response) => response.json())
    .then((data) => {
      console.log(JSON.stringify(data, null, 2));
      return {
        statuscode: 200,
        body: JSON.stringify(data, null, 2),
      };
    })
    .catch((e) => {
      console.log("Error:", e);
    });
};
